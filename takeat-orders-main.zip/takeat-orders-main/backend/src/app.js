import cors from "cors";
import express from "express";
import { errorHandler } from "./middlewares/errorHandler.js";
import docsRoutes from "./routes/docs.routes.js";
import routes from "./routes/index.js";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/docs", docsRoutes);
app.use("/api", routes);

app.use(errorHandler);

export default app;
